
import { config } from 'dotenv';
config();

import '@/ai/flows/translate-text.ts';
import '@/ai/flows/extract-text-from-file-flow.ts'; // Updated flow name

